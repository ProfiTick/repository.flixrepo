# -*- coding: utf-8 -*-
import xbmcgui
import xbmc

class DeviceAuthDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, xmlFilename, scriptPath, code, url):
        super(DeviceAuthDialog, self).__init__(xmlFilename, scriptPath)
        self.code = code
        self.url = url
        self.canceled = False

    def onInit(self):
        self.setProperty('trakt.code', self.code)
        self.setProperty('trakt.url', self.url)
        self.setFocusId(10)

    def onClick(self, controlId):
        if controlId == 10:
            self.canceled = True
            self.close()

    def is_canceled(self):
        return self.canceled 