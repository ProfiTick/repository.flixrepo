# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import os
import json
from urllib.parse import urlencode, quote, urlparse, parse_qsl
from urllib.request import urlopen, Request
import re
import datetime
from bs4 import BeautifulSoup
import requests
import unicodedata
import time
import hjson
import xbmcvfs
from collections import defaultdict
import hjson.trakt_api
from trakt import Trakt


_url = sys.argv[0]
_handle = int(sys.argv[1])


addon = xbmcaddon.Addon(id='plugin.video.czechflix')
ls = addon.getSetting("ls")
download_path = addon.getSetting("download")
history_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.prehrajto'),'resources', 'history.txt')
subtitles_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.prehrajto'),'resources', 'subtitles.txt')
qr_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.prehrajto'),'resources', 'qr.png')
gid = {28: "Akční", 12: "Dobrodružný", 16: "Animovaný", 35: "Komedie", 80: "Krimi", 99: "Dokumentární", 18: "Drama", 10751: "Rodinný", 14: "Fantasy", 36: "Historický", 27: "Horor", 10402: "Hudební", 9648: "Mysteriózní", 10749: "Romantický", 878: "Vědeckofantastický", 10770: "Televizní film", 53: "Thriller", 10752: "Válečný", 37: "Western", 10759: "Action & Adventure", 10751: "Rodinný", 10762: "Kids", 9648: "Mysteriózní", 10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy", 10766: "Soap", 10767: "Talk", 10768: "War & Politics"}
headers = {'user-agent': 'kodi/prehraj.to'}

# Add a global variable to track if we've shown the notification this session
shown_premium_notification = False

trakt_api = hjson.trakt_api.TraktAPI('plugin.video.czechflix')


def encode(string):
    line = unicodedata.normalize('NFKD', string)
    output = ''
    for c in line:
        if not unicodedata.combining(c):
            output += c
    return output


def get_premium(show_notification=False):
    global shown_premium_notification
    try:
        email = addon.getSetting("email")
        password = addon.getSetting("password")
        if not email or not password:
            if show_notification:
                xbmcgui.Dialog().notification("Přehraj.to", "Není zadán email nebo heslo v nastavení!", xbmcgui.NOTIFICATION_ERROR, 5000, sound=False)
            return 0, None
        login = {"password": password, "email": email, '_submit': 'Přihlásit+se', 'remember': 'on', '_do': 'login-loginForm-submit'}
        res = requests.post("https://prehraj.to/", login)
        soup = BeautifulSoup(res.content, "html.parser")
        title = soup.find('ul', {'class': 'header__links'})
        title = title.find('span', {'class': 'color-green'}) if title else None
        if title is None:
            premium = 0
            cookies = res.cookies
            if show_notification:
                xbmcgui.Dialog().notification("Přehraj.to", "Přihlášení selhalo!", xbmcgui.NOTIFICATION_ERROR, 4000, sound=False)
        else:
            premium = 1
            cookies = res.cookies
            if show_notification:
                xbmcgui.Dialog().notification("Přehraj.to", "Úspěšně Přihlášen!", xbmcgui.NOTIFICATION_INFO, 4000, sound=False)
            # Do NOT show premium days notification here to avoid duplicates.

            if not shown_premium_notification:
                shown_premium_notification = True
        return premium, cookies
    except Exception as e:
        if show_notification:
            xbmcgui.Dialog().notification("Přehraj.to", f"Chyba při přihlášení: {e}", xbmcgui.NOTIFICATION_ERROR, 5000, sound=False)
        return 0, None

        cookies = ''
    return premium, cookies


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def convert_size(number_of_bytes):
    if number_of_bytes < 0:
        raise ValueError("!!! number_of_bytes can't be smaller than 0 !!!")
    step_to_greater_unit = 1024.
    number_of_bytes = float(number_of_bytes)
    unit = 'bytes'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'KB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'MB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'GB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'TB'
    precision = 1
    number_of_bytes = round(number_of_bytes, precision)
    return str(number_of_bytes) + ' ' + unit


def get_link(gl):
    soup = BeautifulSoup(gl, 'html.parser')
    pattern = re.compile('.*var sources = \[(.*?);.*', re.DOTALL)
    script = soup.find("script", string = pattern).string
    try:
        file = re.compile('.*file: "(.*?)".*', re.DOTALL)
        sources = re.compile('.*var sources = \[(.*?);.*', re.DOTALL)
        sources = sources.findall(script)
        for item in sources:
            file1 = file.findall(item)[0]
    except:
        src = re.compile('.*src: "(.*?)".*', re.DOTALL)
        file1 = src.findall(pattern.findall(script)[0])[0]
    try:
        pattern = re.compile('.*var tracks = (.*?);.*', re.DOTALL)
        script = soup.find("script", text=pattern).string
        data = hjson.loads(pattern.findall(script)[0])
        file2 = json.loads(json.dumps(data))[0]["src"]
    except:
        file2 = ""
    f = open(subtitles_path, "w", encoding="utf-8")
    f.write(file2)
    f.close()
    return file1, file2


def play_video_premium(link, cookies):
    link = "https://prehraj.to" + urlparse(link).path
    url = requests.get(link, cookies=cookies).content
    file, sub = get_link(url)
    res = requests.get(link + "?do=download", cookies = cookies, headers=headers, allow_redirects=False)
    file = res.headers['Location']
    listitem = xbmcgui.ListItem(path = file)
    if sub != "":
        subtitles = []
        subtitles.append(sub)
        listitem.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)
    # Mark as watched or in progress depending on playback position
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    while not player.isPlaying() and not monitor.abortRequested():
        xbmc.sleep(200)
    while player.isPlaying() and not monitor.abortRequested():
        xbmc.sleep(500)
    try:
        total_time = player.getTotalTime()
        pos = player.getTime()
        if total_time > 0:
            if pos >= total_time * 0.95:
                set_watched(link)
            else:
                set_in_progress(link)
    except Exception:
        pass




def play_video(link):
    url = requests.get("https://prehraj.to" + urlparse(link).path, headers=headers).content
    file, sub = get_link(url)
    listitem = xbmcgui.ListItem(path = file)
    if sub != "":
        subtitles = []
        subtitles.append(sub)
        listitem.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)
    # Mark as watched or in progress depending on playback position
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    # Wait for playback to start
    while not player.isPlaying() and not monitor.abortRequested():
        xbmc.sleep(200)
    # Wait for playback to end or abort
    while player.isPlaying() and not monitor.abortRequested():
        xbmc.sleep(500)
    try:
        total_time = player.getTotalTime()
        pos = player.getTime()
        if total_time > 0:
            if pos >= total_time * 0.95:
                set_watched(link)
            else:
                set_in_progress(link)
    except Exception:
        pass




def history():
    name_list = open(history_path, "r", encoding="utf-8").read().splitlines()
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category)
        url = get_url(action='listing_search', name = category)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def search(name):
    if name == "None":
        kb = xbmc.Keyboard("", 'Zadejte název filmu nebo seriálu')
        kb.doModal()
        if not kb.isConfirmed():
            return
        q = kb.getText()
        if q == "":
            return
    else:
        q = encode(name)
    if os.path.exists(history_path):
        lh = open(history_path, "r").read().splitlines()
        if q not in lh:
            if len(lh) == 10:
                del lh[-1]
            lh.insert(0, q)
            f = open(history_path, "w")
            for item in lh:
                f.write("%s\n" % item)
            f.close()
    else:
        f = open(history_path, "w")
        f.write(q)
        f.close()
    p = 1
    videos = []
    premium = 0
    if addon.getSetting("email") and len(addon.getSetting("email")) > 0:
        premium, cookies = get_premium()
    while True:
        if premium == 1:
            html = requests.get('https://prehraj.to:443/hledej/' + quote(q) + '?vp-page=' + str(p), cookies=cookies).content
        else:
            html = requests.get('https://prehraj.to:443/hledej/' + quote(q) + '?vp-page=' + str(p)).content
        soup = BeautifulSoup(html, "html.parser")
        title = soup.find_all('h3',attrs={'class': 'video__title'})
        size = soup.find_all('div',attrs={'class': 'video__tag--size'})
        time = soup.find_all('div',attrs={'class': 'video__tag--time'})
        link = soup.find_all('a',{'class': 'video--link'})
        next = soup.find_all('div',{'class': 'pagination-more'})
        for t,s,l,m in zip(title,size,link,time):
            videos.append((t.text , " (" + s.text + " - " + m.text + ")", 'https://prehraj.to:443' + l['href']))
        p = p + 1
        if next == [] or len(videos) > int(ls):
            break
    if videos == []:
        xbmcgui.Dialog().notification("Přehraj.to","Nenalezeno", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        return
    xbmcplugin.setContent(_handle, 'videos')
    # Group by title
    grouped = defaultdict(list)
    for title, info, url in videos:
        grouped[title].append((info, url))
    for title, sources in grouped.items():
        list_item = xbmcgui.ListItem(label=title)
        url = get_url(action='show_sources', name=title)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)  # True = directory
    xbmcplugin.endOfDirectory(_handle)


def tmdb_episodes(name, type, ses_num, fanart, thumb):
    html = urlopen('https://api.themoviedb.org/3/tv/' + type + '/season/' + ses_num + '?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS').read()
    res = json.loads(html)
    for category in res['episodes']:
        if category['name'] != 'Speciály':
            list_item = xbmcgui.ListItem(label=category['name'])
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            full_name = name + ' S' + str(category['season_number']).zfill(2) + 'E' + str(category['episode_number']).zfill(2)
            url = get_url(action='listing_search', name = full_name, type = type)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_seasons(name, type):
    html = urlopen('https://api.themoviedb.org/3/tv/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS').read()
    res = json.loads(html)
    try:
        fanart = "https://image.tmdb.org/t/p/w1280" + res["backdrop_path"]
    except:
        fanart = ""
    for category in res['seasons']:
        if category['name'] != 'Speciály':
            list_item = xbmcgui.ListItem(label=category['name'])
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_episodes', name = name, type = type, ses_num = str(category['season_number']), fanart = fanart, thumb = thumb)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_serie(page, type):
    if type == 'trending':
        return tmdb_trending_serie(page)
    if type == 'recommended':
        return listing_recommended('tv')
    p = int(page)
    sort_by = addon.getSetting("sort_tv") or "popularity.desc"
    # Use /discover/tv for custom sorting
    if type in ["popular", "top_rated", "on_the_air"]:
        url_tmdb = f'https://api.themoviedb.org/3/discover/tv?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page={p}&sort_by={sort_by}'
        html = urlopen(url_tmdb).read()
    else:
        html = urlopen('https://api.themoviedb.org/3/tv/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    res["results"].append({"name": "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category.get('name', ''))
        if category.get('name', '') == "Další":
            url = get_url(action='listing_tmdb_serie', name = str(p + 1), type = type)
        else:
            gl = []
            for g in category.get("genre_ids", []):
                gl.append(gid.get(g, str(g)))
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category.get("backdrop_path", "")
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category.get("poster_path", "")
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_seasons', name = category.get('name', ''), type = category.get("id", ""))
            # Add Show Details context menu
            if 'id' in category:
                list_item.addContextMenuItems([
                    ('Show Details',
                     'RunPlugin({})'.format(get_url(action='show_details', id=category['id'], media_type='tv')))
                ], replaceItems=False)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)

def tmdb_trending_serie(page):
    p = int(page)
    html = urlopen('https://api.themoviedb.org/3/trending/tv/day?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category.get('name', ''))
        gl = []
        for g in category.get("genre_ids", []):
            gl.append(gid.get(g, str(g)))
        try:
            fanart = "https://image.tmdb.org/t/p/w1280" + category.get("backdrop_path", "")
        except:
            fanart = ""
        try:
            thumb = "http://image.tmdb.org/t/p/w342" + category.get("poster_path", "")
        except:
            thumb = ""
        list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
        url = get_url(action='listing_seasons', name = category.get('name', ''), type = category.get("id", ""))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_movie(page, type):
    if type == 'trending':
        return tmdb_trending_movie(page)
    if type == 'recommended':
        return listing_recommended('movie')
    p = int(page)
    sort_by = addon.getSetting("sort_movie") or "popularity.desc"
    # Use /discover/movie for custom sorting
    if type in ["popular", "top_rated", "now_playing"]:
        url_tmdb = f'https://api.themoviedb.org/3/discover/movie?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page={p}&sort_by={sort_by}'
        html = urlopen(url_tmdb).read()
    else:
        html = urlopen('https://api.themoviedb.org/3/movie/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    res["results"].append({"title": "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category.get('title', ''))
        if category.get('title', '') == "Další":
            url = get_url(action='listing_tmdb_movie', name = str(p + 1), type = type)
        else:
            gl = []
            for g in category.get("genre_ids", []):
                gl.append(gid.get(g, str(g)))
            try:
                year = category.get("release_date", "")[:4]
            except:
                year = ""
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category.get("backdrop_path", "")
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category.get("poster_path", "")
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_search', name = category.get('title', '') + " " + year, type = type)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)

def tmdb_trending_movie(page):
    p = int(page)
    html = urlopen('https://api.themoviedb.org/3/trending/movie/day?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category.get('title', ''))
        gl = []
        for g in category.get("genre_ids", []):
            gl.append(gid.get(g, str(g)))
        try:
            year = category.get("release_date", "")[:4]
        except:
            year = ""
        try:
            fanart = "https://image.tmdb.org/t/p/w1280" + category.get("backdrop_path", "")
        except:
            fanart = ""
        try:
            thumb = "http://image.tmdb.org/t/p/w342" + category.get("poster_path", "")
        except:
            thumb = ""
        list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
        url = get_url(action='listing_search', name = category.get('title', '') + " " + year, type = 'movie')
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)

def listing_recommended(media_type):
    xbmcgui.Dialog().notification("Recommended", "Personalized recommendations coming soon!", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_serie_genre(page, type, id):
    p = int(page)
    html = urlopen('https://api.themoviedb.org/3/discover/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&with_genres=' + id + '&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    res["results"].append({"name": "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['name'])
        if category['name'] == "Další":
            url = get_url(action='listing_genre', id = id, type = type, page = str(p + 1))
        else:
            gl = []
            for g in category["genre_ids"]:
                gl.append(gid[g])
            genre = " / ".join(gl)
            try:
                year = category['first_air_date'].split('-')[0]
            except:
                year = ''
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': category['name'], "plot": category['overview'], "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_seasons', name = category['name'], type = category["id"])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_movie_genre(page, type, id):
    p = int(page)
    html = urlopen('https://api.themoviedb.org/3/discover/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&with_genres=' + id + '&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    res["results"].append({"title": "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category['title'])
        if category['title'] == "Další":
            url = get_url(action='listing_genre', id = id, type = type, page = str(p + 1))
        else:
            gl = []
            for g in category["genre_ids"]:
                gl.append(gid[g])
            genre = " / ".join(gl)
            try:
                year = category['release_date'].split('-')[0]
            except:
                year = ''
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': category['title'], "plot": category['overview'], "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_search', name = category['title'] + " " + year, type = type)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def genres_category(type):
    html = urlopen('https://api.themoviedb.org/3/genre/' + type + '/list?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS').read()
    res = json.loads(html)
    for category in res['genres']:
        list_item = xbmcgui.ListItem(label=category['name'])
        url = get_url(action='listing_genre', id = str(category['id']), type = type, page = '1')
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def tmdb_year(page, type, id):
    if type == 'movie':
        title = 'title'
        rd = 'release_date'
        fy = 'primary_release_year'
    else:
        title = 'name'
        rd = 'first_air_date'
        fy = 'first_air_date_year'
    p = int(page)
    html = urlopen('https://api.themoviedb.org/3/discover/' + type + '?api_key=1f0150a5f78d4adc2407911989fdb66c&' + fy + '=' + id + '&language=cs-CS&page=' + str(p)).read()
    res = json.loads(html)
    res["results"].append({title: "Další"})
    xbmcplugin.setContent(_handle, 'videos')
    for category in res['results']:
        list_item = xbmcgui.ListItem(label=category[title])
        if category[title] == "Další":
            url = get_url(action='listing_year', id = id, type = type, page = str(p + 1))
        else:
            gl = []
            for g in category["genre_ids"]:
                gl.append(gid[g])
            genre = " / ".join(gl)
            try:
                year = category[rd].split('-')[0]
            except:
                year = ''
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': category[title], "plot": category['overview'], "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            if type == 'movie':
                url = get_url(action='listing_search', name = category[title] + " " + year, type = type)
            else:
                url = get_url(action='listing_seasons', name = category[title], type = category["id"])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def years_category(type):
    year = datetime.datetime.today().year
    YEARS = [year - i for i in range(101)]
    for category in YEARS:
        list_item = xbmcgui.ListItem(label=str(category))
        url = get_url(action='listing_year', type = type, id = str(category), page = '1')
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def search_tmdb(name, type):
    if name == "movie":
        stitle = "filmu"
    else:
        stitle = "seriálu"
    kb = xbmc.Keyboard("", 'Zadejte název ' + stitle)
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText()
    if q == "":
        return
    html = urlopen('https://api.themoviedb.org/3/search/' + name + '?api_key=1f0150a5f78d4adc2407911989fdb66c&language=cs-CS&page=1&include_adult=false&query=' + quote(q)).read()
    res = json.loads(html)
    xbmcplugin.setContent(_handle, 'videos')
    icons_path = xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/icons')
    if name == "movie":
        for category in res['results']:
            label = category['title']
            list_item = xbmcgui.ListItem(label=label)
            gl = []
            for g in category["genre_ids"]:
                gl.append(gid[g])
            genre = " / ".join(gl)
            try:
                year = category['release_date'].split('-')[0]
            except:
                year = ''
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': label, "plot": category['overview'], "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            # Watched/in-progress icons
            icon = None
            if category.get('watched'):
                icon = os.path.join(icons_path, 'trakt-watched.png')
            elif category.get('in_progress'):
                icon = os.path.join(icons_path, 'continue_watching.png')
            if icon and xbmcvfs.exists(icon):
                list_item.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
            else:
                list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_search', name = label + " " + year, type = type)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)

    else:
        icons_path = xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/icons')
        for category in res['results']:
            label = category['name']
            list_item = xbmcgui.ListItem(label=label)
            gl = []
            for g in category["genre_ids"]:
                gl.append(gid[g])
            genre = " / ".join(gl)
            try:
                year = category['first_air_date'].split('-')[0]
            except:
                year = ''
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': label, "plot": category['overview'], "year": year, 'genre': genre, 'rating': str(category["vote_average"])[:3]})
            try:
                fanart = "https://image.tmdb.org/t/p/w1280" + category["backdrop_path"]
            except:
                fanart = ""
            try:
                thumb = "http://image.tmdb.org/t/p/w342" + category["poster_path"]
            except:
                thumb = ""
            # Watched/in-progress icons
            icon = None
            if category.get('watched'):
                icon = os.path.join(icons_path, 'trakt-watched.png')
            elif category.get('in_progress'):
                icon = os.path.join(icons_path, 'continue_watching.png')
            if icon and xbmcvfs.exists(icon):
                list_item.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
            else:
                list_item.setArt({'thumb':thumb , 'icon': thumb, 'fanart': fanart})
            url = get_url(action='listing_seasons', name = label, type = category["id"])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)

    xbmcplugin.endOfDirectory(_handle)


def movie_category():
    name_list = [
        ("Aktuální trendy", "listing_tmdb_movie", "1", "trending"),
        ("Nedávno přidané", "listing_tmdb_movie", "1", "now_playing"),
        ("Nejlépe hodnocené", "listing_tmdb_movie", "1", "top_rated"),
        ("Oblíbené", "listing_tmdb_movie", "1", "popular"),
        ("Doporučeno", "listing_tmdb_movie", "1", "recommended"),
        ("Oblíbené", "listing_favorites", "movie", ""),
        ("Žánry", "listing_genre_category", "movie", ""),
        ("Rok", "listing_year_category", "movie", ""),
        ("Hledat", "search_tmdb", "movie", "1"),
        ("Nastavit pořadí řazení", "set_sort_order", "movie", "")
    ]
    
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action=category[1], name=category[2], type=category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)



def serie_category():
    name_list = [
        ("Aktuální trendy", "listing_tmdb_serie", "1", "trending"),
        ("Nedávno přidané", "listing_tmdb_serie", "1", "on_the_air"),
        ("Nejlépe hodnocené", "listing_tmdb_serie", "1", "top_rated"),
        ("Oblíbené", "listing_tmdb_serie", "1", "popular"),
        ("Doporučeno", "listing_tmdb_serie", "1", "recommended"),
        ("Oblíbené", "listing_favorites", "tv", ""),
        ("Žánry", "listing_genre_category", "tv", ""),
        ("Rok", "listing_year_category", "tv", ""),
        ("Hledat", "search_tmdb", "tv", "1"),
        ("Nastavit pořadí řazení", "set_sort_order", "tv", "")
    ]
    
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action=category[1], name=category[2], type=category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)



def menu():
    # Main menu with Trakt actions
    menu_items = [
        ("Hledat", "listing_search", "None", ""),
        ("Filmy", "listing_movie_category", "", ""),
        ("Seriály", "listing_serie_category", "", ""),
        ("Favorites", "listing_favorites", "all", ""),
        ("Test Premium Login", "test_premium", "", "")
    ]
    
    # Add History if it exists
    if os.path.exists(history_path):
        menu_items.insert(1, ("Historie hledání", "listing_history", "None", ""))
        
    # Add Trakt option if enabled
    if addon.getSettingBool('trakt.enabled'):
        trakt_user = addon.getSetting('trakt.user')
        label = f"Trakt.tv ({trakt_user})" if trakt_user else "Trakt.tv"
        menu_items.append((label, "trakt_sync_watched", "", ""))
    
    # Display menu items
    for category in menu_items:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action=category[1], name=category[2], type=category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)



import threading

FAVORITES_PATH = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix'), 'favorites.json')

# Thread-safe load/save for favorites
_favorites_lock = threading.Lock()

def load_favorites():
    if not xbmcvfs.exists(FAVORITES_PATH):
        return {"movie": [], "tv": []}
    with _favorites_lock:
        with xbmcvfs.File(FAVORITES_PATH, 'r') as f:
            try:
                data = f.read().decode('utf-8') if hasattr(f, 'decode') else f.read()
                return json.loads(data)
            except Exception:
                return {"movie": [], "tv": []}

def save_favorites(favorites):
    with _favorites_lock:
        with xbmcvfs.File(FAVORITES_PATH, 'w') as f:
            f.write(json.dumps(favorites, ensure_ascii=False, indent=2))

def mark_unwatched(item_id, media_type):
    favorites = load_favorites()
    for fav in favorites.get(media_type, []):
        if str(fav.get('id')) == str(item_id):
            fav['watched'] = False
            fav['in_progress'] = False
    save_favorites(favorites)

def set_in_progress(link):
    # Try to mark the matching favorite as in_progress
    favorites = load_favorites()
    for media_type in ['movie', 'tv']:
        for fav in favorites.get(media_type, []):
            # Match by id or title in link
            if str(fav.get('id')) in link or fav.get('title', '') in link or fav.get('name', '') in link:
                fav['in_progress'] = True
                fav['watched'] = False
    save_favorites(favorites)

def set_watched(link):
    # Try to mark the matching favorite as watched
    favorites = load_favorites()
    for media_type in ['movie', 'tv']:
        for fav in favorites.get(media_type, []):
            if str(fav.get('id')) in link or fav.get('title', '') in link or fav.get('name', '') in link:
                fav['watched'] = True
                fav['in_progress'] = False
    save_favorites(favorites)


def add_to_favorites(item, media_type):
    favorites = load_favorites()
    if not any(f['id'] == item['id'] for f in favorites[media_type]):
        favorites[media_type].append(item)
        save_favorites(favorites)

def remove_from_favorites(item_id, media_type):
    favorites = load_favorites()
    favorites[media_type] = [f for f in favorites[media_type] if f['id'] != item_id]
    save_favorites(favorites)

def is_favorite(item_id, media_type):
    favorites = load_favorites()
    return any(f['id'] == item_id for f in favorites[media_type])

def listing_favorites(type, extra=None):
    favorites = load_favorites()
    # Show all if type == 'all', else filter
    items = []
    if type == 'all':
        items = favorites['movie'] + favorites['tv']
    else:
        items = favorites.get(type, [])
    if not items:
        xbmcgui.Dialog().notification("Favorites", "No favorites yet.", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle)
        return
    icons_path = xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/icons')
    for fav in items:
        label = fav.get('title', fav.get('name', 'Unknown'))
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'title': label})
        url = get_url(action='listing_seasons' if fav['type']=='tv' else 'listing_search', name=fav['id'], type=fav['type'])
        # Watched/in-progress icons
        if fav.get('watched'):
            icon = os.path.join(icons_path, 'trakt-watched.png')
        elif fav.get('in_progress'):
            icon = os.path.join(icons_path, 'continue_watching.png')
        else:
            icon = None
        if icon and xbmcvfs.exists(icon):
            list_item.setArt({'thumb': icon, 'icon': icon})
        context_menu = [
            ('Remove from Favorites',
             'RunPlugin({})'.format(get_url(action='remove_favorite', id=fav['id'], media_type=fav['type'])))
        ]
        if fav.get('watched') or fav.get('in_progress'):
            context_menu.append(
                ('Mark as Unwatched',
                 'RunPlugin({})'.format(get_url(action='mark_unwatched', id=fav['id'], media_type=fav['type'])))
            )
        list_item.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


# Patch: Add context menu for Add/Remove Favorites in show_sources()
# (You may need to extend this to other listing functions as needed)




def get_premium_days():
    """
    Returns the number of days remaining for premium, or None if not premium, or an error message if something goes wrong.
    """
    if addon.getSetting("email") != '':
        login = {"password": addon.getSetting("password"),"email": addon.getSetting("email"), '_submit': 'Přihlásit+se', 'remember': 'on', '_do': 'login-loginForm-submit'}
        res = requests.post("https://prehraj.to/", login)
        soup = BeautifulSoup(res.content, "html.parser")
        # 1. Check for <span class="color-green"> (premium)
        span_green = soup.find('span', {'class': 'color-green'})
        if span_green and span_green.text:
            match = re.search(r'(\d+)\s*dní', span_green.text)
            if match:
                return int(match.group(1))
        # 2. Check for <span class="color-primary">Neaktivní</span> (not premium)
        span_primary = soup.find('span', {'class': 'color-primary'})
        if span_primary and 'neaktivní' in span_primary.text.lower():
            return None  # Not premium
        # 3. Look for 'Vyprší za <strong>XX dní</strong>'
        vyprsi = soup.find_all('p', string=re.compile(r'Vyprší za'))
        for p in vyprsi:
            strong = p.find('strong') if p else None
            if strong and strong.text:
                match = re.search(r'(\d+)\s*dní', strong.text)
                if match:
                    return int(match.group(1))
        # 4. Fallback: any <strong> tag with 'dní'
        strongs = soup.find_all('strong')
        for s in strongs:
            if s and s.text and re.search(r'(\d+)\s*dní', s.text):
                match = re.search(r'(\d+)\s*dní', s.text)
                if match:
                    return int(match.group(1))
        # 5. If nothing found, check for 'Neaktivní' anywhere
        if soup.find(string=re.compile(r'Neaktivní', re.I)):
            return None
        # 6. If nothing found, return a snippet for debugging
        snippet = soup.prettify()[:1000]
        return f"Nepodařilo se najít informaci o PREMIUM.\nHTML začátek:\n{snippet}"
    else:
        return "Nemáte nastavený email v nastavení."


def show_premium_days():
    days = get_premium_days()
    if isinstance(days, int):
        xbmcgui.Dialog().ok('Přehraj.to', f'Zbývá {days} dní vašeho PREMIUM účtu.')
    else:
        xbmcgui.Dialog().ok('Přehraj.to', str(days))


def choose_sort_option(media_type):
    sort_labels = ["Popularity", "Release Date", "Rating", "Alphabetically"]
    sort_values = [
        "popularity.desc",
        "release_date.desc" if media_type == 'movie' else "first_air_date.desc",
        "vote_average.desc",
        "original_title.asc" if media_type == 'movie' else "original_name.asc"
    ]
    dialog = xbmcgui.Dialog()
    idx = dialog.select("Choose sort order", sort_labels)
    if idx != -1:
        addon.setSetting(f"sort_{media_type}", sort_values[idx])
        xbmcgui.Dialog().notification("Sort Order", f"Set to {sort_labels[idx]}", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().notification("Sort Order", "No change", xbmcgui.NOTIFICATION_INFO, 2000)

def show_details(tmdb_id, media_type):
    # Fetch details from TMDb
    import webbrowser
    api_key = "1f0150a5f78d4adc2407911989fdb66c"
    base_url = "https://api.themoviedb.org/3/"
    details_url = f"{base_url}{'movie' if media_type == 'movie' else 'tv'}/{tmdb_id}?api_key={api_key}&language=cs-CS"
    credits_url = f"{base_url}{'movie' if media_type == 'movie' else 'tv'}/{tmdb_id}/credits?api_key={api_key}&language=cs-CS"
    videos_url = f"{base_url}{'movie' if media_type == 'movie' else 'tv'}/{tmdb_id}/videos?api_key={api_key}&language=cs-CS"
    similar_url = f"{base_url}{'movie' if media_type == 'movie' else 'tv'}/{tmdb_id}/similar?api_key={api_key}&language=cs-CS"
    try:
        details = json.loads(urlopen(details_url).read())
        credits = json.loads(urlopen(credits_url).read())
        videos = json.loads(urlopen(videos_url).read())
        similar = json.loads(urlopen(similar_url).read())
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Failed to fetch details: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    title = details.get('title', details.get('name', 'Unknown'))
    overview = details.get('overview', '-')
    rating = details.get('vote_average', '-')
    genres = ', '.join([g['name'] for g in details.get('genres', [])])
    cast = ', '.join([c['name'] for c in credits.get('cast', [])[:5]])
    trailer_url = None
    for v in videos.get('results', []):
        if v.get('site') == 'YouTube' and v.get('type') == 'Trailer':
            trailer_url = f'https://www.youtube.com/watch?v={v["key"]}'
            break
    similar_titles = ', '.join([s.get('title', s.get('name', '')) for s in similar.get('results', [])[:3]])
    msg = f"[B]{title}[/B]\n\n[COLOR gold]Genres:[/COLOR] {genres}\n[COLOR gold]Rating:[/COLOR] {rating}\n[COLOR gold]Cast:[/COLOR] {cast}\n\n[COLOR gold]Overview:[/COLOR]\n{overview}\n\n[COLOR gold]Similar:[/COLOR] {similar_titles}"
    if trailer_url:
        msg += f"\n\n[COLOR gold]Trailer:[/COLOR] [I]Open in browser[/I]"
    ok = xbmcgui.Dialog().ok(title, msg)
    if trailer_url and ok:
        webbrowser.open(trailer_url)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        # Handle Trakt specific actions
        if params.get("action") in ["trakt_login", "trakt_logout", "trakt_sync_watched", "trakt_watched", "trakt_recommended"]:
            # All Trakt actions require Trakt to be enabled
            if not addon.getSettingBool('trakt.enabled'):
                xbmcgui.Dialog().notification("Trakt", "Trakt.tv není povolen v nastavení!", xbmcgui.NOTIFICATION_ERROR, 4000)
                return
                
            # Actions that require authentication
            if params.get("action") in ["trakt_logout", "trakt_sync_watched", "trakt_watched", "trakt_recommended"]:
                if not trakt_api.is_authenticated():
                    xbmcgui.Dialog().notification("Trakt", "Nejste přihlášeni k Trakt.tv", xbmcgui.NOTIFICATION_ERROR, 4000)
                    return
            
            # Handle each Trakt action
            if params.get("action") == "trakt_login":
                if trakt_api.login():
                    trakt_api.get_user()
                return
            elif params.get("action") == "trakt_logout":
                trakt_api.logout()
                return
            elif params.get("action") == "trakt_sync_watched":
                trakt_api.sync_watched()
                return
            elif params.get("action") == "trakt_watched":
                show_trakt_watched(params["type"])
                return
            elif params.get("action") == "trakt_recommended":
                show_trakt_recommended(params["type"])
                return
        
        # Handle all other actions
        if params.get("action") == "set_sort_order":
            choose_sort_option(params["name"])
            return
        if params.get("action") == "show_details":
            show_details(params["id"], params["media_type"])
            return
        if params["action"] == "listing_search":
            search(params["name"])
        elif params["action"] == "listing_history":
            history()
        elif params["action"] == "listing_episodes":
            tmdb_episodes(params["name"], params["type"], params["ses_num"], params["fanart"], params["thumb"])
        elif params["action"] == "listing_seasons":
            tmdb_seasons(params["name"], params["type"])
        elif params["action"] == "listing_year":
            tmdb_year(params["page"], params["type"], params["id"])
        elif params["action"] == "test_premium":
            premium, _ = get_premium(show_notification=True)
            if premium == 1:
                days = get_premium_days()
                if isinstance(days, int):
                    xbmcgui.Dialog().notification("Přehraj.to", f"PREMIUM zbývá {days} dní", xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            menu()
            return
        elif params["action"] == "listing_year_category":
            years_category(params["name"])
        elif params["action"] == "listing_movie_category":
            movie_category()
        elif params["action"] == "listing_serie_category":
            serie_category()
        elif params["action"] == "listing_genre_category":
            genres_category(params["name"])
        elif params["action"] == "listing_genre":
            if params["type"] == 'movie':
                tmdb_movie_genre(params["page"], params["type"], params["id"])
            else:
                tmdb_serie_genre(params["page"], params["type"], params["id"])
        elif params["action"] == "listing_tmdb_movie":
            tmdb_movie(params["name"], params["type"])
        elif params["action"] == "listing_tmdb_serie":
            tmdb_serie(params["name"], params["type"])
        elif params["action"] == "search_tmdb":
            search_tmdb(params["name"], params["type"])
        elif params["action"] == "play":
            premium, cookies = get_premium()
            if premium == 1:
                play_video_premium(params["link"], cookies)
            else:
                play_video(params["link"])
        elif params["action"] == "library":
            if addon.getSetting("library") == "":
                xbmcgui.Dialog().notification("Přehraj.to","Nastavte složku pro knihovnu", xbmcgui.NOTIFICATION_ERROR, 3000)
                return
            parsed1 = urlparse(params["url"]).path
            name = parsed1.split("/")[1]
            kb = xbmc.Keyboard(name.replace("-", " "), 'Zadejte název a rok filmu')
            kb.doModal()
            if not kb.isConfirmed():
                return
            q = kb.getText()
            if q == "":
                return
            f = open(addon.getSetting("library") + q +  ".strm", "w")
            f.write("plugin://plugin.video.prehrajto/?action=play&link=" + params["url"])
            f.close()
            xbmcgui.Dialog().notification("Přehraj.to","Uloženo", xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
        elif params["action"] == "qr":
            u = requests.get(params["url"]).content
            file, sub = get_link(u)
            qr_link = "https://chart.googleapis.com/chart?chs=500x500&cht=qr&choe=UTF-8&chl=" + file.replace('&', '%26')
            xbmc.executebuiltin('ShowPicture('+qr_link+')')
        elif params["action"] == "download":
            if addon.getSetting("download") == "":
                xbmcgui.Dialog().notification("Přehraj.to","Nastavte složku pro stahování", xbmcgui.NOTIFICATION_ERROR, 4000)
                return
            u = requests.get(params["url"]).content
            file, sub = get_link(u)
            parsed1 = urlparse(params["url"]).path
            parsed2 = urlparse(file).path
            name = parsed1.split("/")[1] + "." + parsed2.split(".")[-1]
            if sub != "":
                name_subtitles = parsed1.split("/")[1] + ".srt"
                us = urlopen(sub).read()
                fs = open(download_path + name_subtitles, "wb")
                fs.write(us)
                fs.close()
            premium, cookies = get_premium()
            if premium == 1:
                res = requests.get(params["url"] + "?do=download", cookies = cookies, allow_redirects=False)
                file = res.headers['Location']
            dialog = xbmcgui.DialogProgress()
            u = urlopen(file)
            f = open(download_path + name, "wb")
            file_size = int(u.getheader("Content-Length"))
            dialog.create("Přehraj.to","Stahování...")
            start = time.time()
            file_size_dl = 0
            block_sz = 4096
            canceled = False
            while True:
                if dialog.iscanceled():
                    canceled = True
                    break
                buffer = u.read(block_sz)
                if not buffer: break
                file_size_dl += len(buffer)
                f.write(buffer)
                status = r"%3.2f%%" % (file_size_dl * 100. / file_size)
                status = status + chr(8)*(len(status)+1)
                done = int(50 * file_size_dl / file_size)
                speed = "%s" % round((file_size_dl//(time.time() - start) / 100000), 1)
                dialog.update(int(file_size_dl*100 /file_size), "Velikost:  " + convert_size(file_size) + "\n" + "Staženo:  " + status + "     Rychlost: " + speed + " Mb/s\n" + name)
            f.close()
            dialog.close()
            if canceled == False:
                dialog = xbmcgui.Dialog()
                dialog.ok('Přehraj.to', 'Soubor stažen\n' + name)
            else:
                os.remove(download_path + name)
                try:
                    os.remove(download_path + name_subtitles)
                except: pass
        elif params["action"] == "show_sources":
            show_sources(params["name"])
        elif params["action"] == "show_premium_days":
            show_premium_days()
        elif params["action"] == "add_favorite":
            add_to_favorites({'id': params['id'], 'title': params['title'], 'type': params['media_type']}, params['media_type'])
            xbmcgui.Dialog().notification("Přehraj.to", "Přidáno do oblíbených", xbmcgui.NOTIFICATION_INFO, 3000)
        elif params["action"] == "remove_favorite":
            remove_from_favorites(params['id'], params['media_type'])
            xbmcgui.Dialog().notification("Přehraj.to", "Odebráno z oblíbených", xbmcgui.NOTIFICATION_INFO, 3000)
        elif params["action"] == "mark_unwatched":
            mark_unwatched(params['id'], params['media_type'])
            xbmcgui.Dialog().notification("Přehraj.to", "Označeno jako neshlédnuté", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        menu()


def extract_size(info):
    # Extract size in GB/MB from info string, convert to bytes for sorting
    import re
    match = re.search(r'(\d+[\.,]?\d*)\s*(GB|MB)', info)
    if not match:
        return 0
    size = float(match.group(1).replace(',', '.'))
    unit = match.group(2)
    if unit == 'GB':
        return int(size * 1024 * 1024 * 1024)
    elif unit == 'MB':
        return int(size * 1024 * 1024)
    return 0

def show_sources(name):
    # Search for all sources for the given name (repeat search logic, but only for this name)
    p = 1
    videos = []
    premium = 0
    if addon.getSetting("email") and len(addon.getSetting("email")) > 0:
        premium, cookies = get_premium()
    while True:
        if premium == 1:
            html = requests.get('https://prehraj.to:443/hledej/' + quote(name) + '?vp-page=' + str(p), cookies=cookies).content
        else:
            html = requests.get('https://prehraj.to:443/hledej/' + quote(name) + '?vp-page=' + str(p)).content
        soup = BeautifulSoup(html, "html.parser")
        title = soup.find_all('h3',attrs={'class': 'video__title'})
        size = soup.find_all('div',attrs={'class': 'video__tag--size'})
        time = soup.find_all('div',attrs={'class': 'video__tag--time'})
        link = soup.find_all('a',{'class': 'video--link'})
        next = soup.find_all('div',{'class': 'pagination-more'})
        for t,s,l,m in zip(title,size,link,time):
            if t.text.strip() == name.strip():
                videos.append((t.text , " (" + s.text + " - " + m.text + ")", 'https://prehraj.to:443' + l['href']))
        p = p + 1
        if next == []:
            break
    # Sort by file size (descending)
    videos.sort(key=lambda x: extract_size(x[1]), reverse=True)
    xbmcplugin.setContent(_handle, 'videos')
    def get_quality_icon(label_info):
        # Map keywords to icon filenames
        quality_map = [
            (r'8K', 'UHD8K-512.png'),
            (r'4K|UHD', 'UHD-512.png'),
            (r'QHD', 'QHD-512.png'),
            (r'FHD|1080', 'FHD-512.png'),
            (r'HD|720', 'HD-512.png'),
            (r'480', 'SD480-512.png'),
            (r'360', 'SD360-512.png'),
            (r'240', 'SD240-512.png'),
            (r'144', 'SD144-512.png'),
        ]
        # Add HDR/DV/3D extensions
        ext_map = [
            (r'HDR', '-HDR'),
            (r'DV', '-DV'),
            (r'3D', '-3D'),
        ]
        label = label_info.upper()
        base_icon = None
        for pattern, icon in quality_map:
            if re.search(pattern, label):
                base_icon = icon.replace('.png', '')
                break
        if not base_icon:
            base_icon = 'HD-512'  # Default
        # Add extensions if present
        for pattern, ext in ext_map:
            if re.search(pattern, label):
                base_icon += ext
        icon_filename = base_icon + '.png'
        icon_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/quality'), icon_filename)
        if not xbmcvfs.exists(icon_path):
            icon_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/quality'), 'HD-512.png')
        return icon_path

    for category in videos:
        label = category[0] + category[1]
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'mediatype' : 'movies', 'title': label})
        list_item.setProperty('IsPlayable', 'true')
        # Set quality icon
        icon_path = get_quality_icon(label)
        list_item.setArt({'thumb': icon_path, 'icon': icon_path})
        # Add context menu for favorites
        item_id = category[2]
        fav_item = {'id': item_id, 'title': label, 'type': 'movie'}
        if is_favorite(item_id, 'movie'):
            list_item.addContextMenuItems([
                ('Remove from Favorites',
                 'RunPlugin({})'.format(get_url(action='remove_favorite', id=item_id, media_type='movie')))
            ])
        else:
            list_item.addContextMenuItems([
                ('Add to Favorites',
                 'RunPlugin({})'.format(get_url(action='add_favorite', id=item_id, title=label, media_type='movie')))
            ])
        list_item.addContextMenuItems([
            ('Uložit do knihovny','RunPlugin({})'.format(get_url(action = "library", url = category[2]))),
            ('Stáhnout','RunPlugin({})'.format(get_url(action = "download", url = category[2]))),
            ('QR kód streamu','RunPlugin({})'.format(get_url(action = "qr", url = category[2])))
        ])
        url = get_url(action='play', link = category[2])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)



def startup_trakt_sync():
    import threading
    def sync():
        access_token = addon.getSetting('trakt_access_token')
        if access_token:
            try:
                trakt_api.sync_watched()
            except Exception as e:
                xbmcgui.Dialog().notification("Trakt", f"Startup sync error: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
    threading.Thread(target=sync, daemon=True).start()

def show_trakt_watched(media_type):
    """Display Trakt watched items for movies or TV shows"""
    if not addon.getSettingBool('trakt.enabled'):
        xbmcgui.Dialog().notification("Trakt", "Trakt.tv není povolen v nastavení!", xbmcgui.NOTIFICATION_ERROR, 4000)
        return
        
    if not trakt_api.is_authenticated():
        xbmcgui.Dialog().notification("Trakt", "Nejste přihlášeni k Trakt.tv", xbmcgui.NOTIFICATION_ERROR, 4000)
        return
        
    try:
        with Trakt.configuration.oauth.from_response(trakt_api.authorization):
            with Trakt.configuration.http(retry=True):
                if media_type == 'movie':
                    items = Trakt['sync/watched'].movies()
                else:
                    items = Trakt['sync/watched'].shows()
                    
        if not items:
            xbmcgui.Dialog().notification("Trakt", f"Žádné sledované {media_type}", xbmcgui.NOTIFICATION_INFO, 3000)
            return
            
        xbmcplugin.setContent(_handle, 'videos')
        for item in items:
            if media_type == 'movie':
                title = item.title
                year = item.year if hasattr(item, 'year') else ""
                list_item = xbmcgui.ListItem(label=f"{title} ({year})" if year else title)
                url = get_url(action='listing_search', name=f"{title} {year}", type='movie')
            else:
                title = item.title
                list_item = xbmcgui.ListItem(label=title)
                url = get_url(action='listing_search', name=title, type='tv')
                
            # Set watched icon
            icon_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/icons'), 'trakt-watched.png')
            if xbmcvfs.exists(icon_path):
                list_item.setArt({'thumb': icon_path, 'icon': icon_path})
                
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
            
        xbmcplugin.endOfDirectory(_handle)
    except Exception as e:
        xbmcgui.Dialog().notification("Trakt", f"Chyba: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)


def show_trakt_recommended(media_type):
    """Display Trakt recommended items for movies or TV shows"""
    if not addon.getSettingBool('trakt.enabled'):
        xbmcgui.Dialog().notification("Trakt", "Trakt.tv není povolen v nastavení!", xbmcgui.NOTIFICATION_ERROR, 4000)
        return
        
    if not trakt_api.is_authenticated():
        xbmcgui.Dialog().notification("Trakt", "Nejste přihlášeni k Trakt.tv", xbmcgui.NOTIFICATION_ERROR, 4000)
        return
        
    try:
        with Trakt.configuration.oauth.from_response(trakt_api.authorization):
            with Trakt.configuration.http(retry=True):
                if media_type == 'movie':
                    items = Trakt['recommendations'].movies()
                else:
                    items = Trakt['recommendations'].shows()
                    
        if not items:
            xbmcgui.Dialog().notification("Trakt", f"Žádná doporučení pro {media_type}", xbmcgui.NOTIFICATION_INFO, 3000)
            return
            
        xbmcplugin.setContent(_handle, 'videos')
        for item in items:
            if media_type == 'movie':
                title = item.title
                year = item.year if hasattr(item, 'year') else ""
                list_item = xbmcgui.ListItem(label=f"{title} ({year})" if year else title)
                url = get_url(action='listing_search', name=f"{title} {year}", type='movie')
            else:
                title = item.title
                list_item = xbmcgui.ListItem(label=title)
                url = get_url(action='listing_search', name=title, type='tv')
                
            # Set icon
            icon_path = os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.czechflix/resources/icons'), 'trakt-recommended.png')
            if xbmcvfs.exists(icon_path):
                list_item.setArt({'thumb': icon_path, 'icon': icon_path})
                
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
            
        xbmcplugin.endOfDirectory(_handle)
    except Exception as e:
        xbmcgui.Dialog().notification("Trakt", f"Chyba: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)

if __name__ == '__main__':
    router(sys.argv[2][1:])
