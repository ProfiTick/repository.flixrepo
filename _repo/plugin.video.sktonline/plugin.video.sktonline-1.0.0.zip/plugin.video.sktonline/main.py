import sys
import urllib.parse
import urllib.request
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import os
import json

addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
base_url = 'https://online.sktorrent.eu'

# Paths for icon and fanart
addon_path = addon.getAddonInfo('path')
icon = os.path.join(addon_path, 'resources', 'icon.png')
fanart = os.path.join(addon_path, 'resources', 'fanart.jpg')
search_icon = os.path.join(addon_path, 'resources', 'icons', 'search.png')
history_icon = os.path.join(addon_path, 'resources', 'icons', 'history.png')
icon_480 = os.path.join(addon_path, 'resources', 'icons', '480.png')
icon_720 = os.path.join(addon_path, 'resources', 'icons', '720.png')
history_file = os.path.join(addon_path, 'history.json')

CATEGORY_PAGES = {
    f"{base_url}/videos": 2401,
    f"{base_url}/videos/dokumenty-cz-sk-dabing": 46,
    f"{base_url}/videos/dokumenty-cz-sk-titulky": 27,
    f"{base_url}/videos/filmy": 9,
    f"{base_url}/videos/filmy-cz-sk": 721,
    f"{base_url}/videos/filmy-cz-sk-titulky": 127,
    f"{base_url}/videos/rozpravky-cz-sk-kreslene-animovane": 67,
    f"{base_url}/videos/serialy-cz-sk": 989,
    f"{base_url}/videos/serialy-cz-sk-titulky": 341,
    f"{base_url}/videos/tv-porady": 56,
}

CATEGORIES = [
    ("Videa", f"{base_url}/videos"),
    ("Dokumenty CZ/SK Dabing", f"{base_url}/videos/dokumenty-cz-sk-dabing"),
    ("Dokumenty CZ/SK Titulky", f"{base_url}/videos/dokumenty-cz-sk-titulky"),
    ("Filmy", f"{base_url}/videos/filmy"),
    ("Filmy CZ/SK", f"{base_url}/videos/filmy-cz-sk"),
    ("Filmy CZ/SK Titulky", f"{base_url}/videos/filmy-cz-sk-titulky"),
    ("Rozpravky CZ/SK Kreslene Animovane", f"{base_url}/videos/rozpravky-cz-sk-kreslene-animovane"),
    ("Serialy CZ/SK", f"{base_url}/videos/serialy-cz-sk"),
    ("Serialy CZ/SK Titulky", f"{base_url}/videos/serialy-cz-sk-titulky"),
    ("TV Porady", f"{base_url}/videos/tv-porady"),
]

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def get_html(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as response:
        return response.read().decode('utf-8', errors='replace')

def parse_og_meta(html, prop):
    # Returns the content of a <meta property="og:..." content="..."> tag
    match = re.search(r'<meta\s+property=["\"]' + re.escape(prop) + r'["\"][^>]*content=["\"]([^"\"]+)["\"][^>]*>', html, re.IGNORECASE)
    if match:
        return match.group(1)
    return None

def get_category_base_and_page(cat_url):
    # Returns (base_url, page_number) for a category page
    m = re.match(r'(.+?)(?:\?page=(\d+))?$', cat_url)
    if m:
        base = m.group(1)
        page = int(m.group(2)) if m.group(2) else 1
        return base, page
    return cat_url, 1

def get_category_name(cat_url):
    for name, url in CATEGORIES:
        if cat_url.startswith(url):
            return name
    return "Videa"

# Cache for video counts
category_video_counts = {}

def get_video_count_for_category(url):
    if url in category_video_counts:
        return category_video_counts[url]
    try:
        html = get_html(url)
        # Look for <span class="text-white">NUMBER</span> videí
        match = re.search(r'<span class="text-white">([\d\s]+)</span>\s*vide[íi]', html)
        if match:
            count = match.group(1).replace(' ', '')
            category_video_counts[url] = count
            return count
    except Exception:
        pass
    return None

def load_history():
    try:
        with open(history_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []

def save_history(history):
    try:
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False)
    except Exception:
        pass

def add_to_history(title, video_url, poster):
    history = load_history()
    # Remove duplicates
    history = [item for item in history if item['video_url'] != video_url]
    # Add to top
    history.insert(0, {'title': title, 'video_url': video_url, 'poster': poster})
    # Limit history size
    history = history[:100]
    save_history(history)

def list_history():
    xbmcplugin.setPluginCategory(addon_handle, 'Historie sledování')
    history = load_history()
    for item in history:
        li = xbmcgui.ListItem(label=item['title'])
        if item.get('poster'):
            li.setArt({'thumb': item['poster'], 'icon': item['poster'], 'fanart': fanart, 'poster': item['poster']})
        else:
            li.setArt({'fanart': fanart})
        li.setInfo('video', {'title': item['title']})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_streams', 'video_url': item['video_url']}),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.setPluginFanart(addon_handle, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

def list_categories():
    # Add search at the top
    li = xbmcgui.ListItem(label='[B]Hledat...[/B]')
    li.setArt({'icon': search_icon, 'thumb': search_icon, 'fanart': fanart})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'search'}),
        listitem=li,
        isFolder=True
    )
    # Add history below search
    li = xbmcgui.ListItem(label='[B]Historie sledování[/B]')
    li.setArt({'icon': history_icon, 'thumb': history_icon, 'fanart': fanart})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({'mode': 'history'}),
        listitem=li,
        isFolder=True
    )
    for name, url in CATEGORIES:
        count = get_video_count_for_category(url)
        display_name = f"{name} ({count} videí)" if count else name
        li = xbmcgui.ListItem(label=display_name)
        # Always use the default icon for all categories in the main page
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_videos', 'cat_url': url}),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.setPluginFanart(addon_handle, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

def list_videos(cat_url):
    base, page = get_category_base_and_page(cat_url)
    max_pages = CATEGORY_PAGES.get(base, 1)
    cat_name = get_category_name(base)
    # Set the directory title to show current page/total pages
    xbmcplugin.setPluginCategory(addon_handle, f"{cat_name} (Page {page}/{max_pages})")
    html = get_html(cat_url)
    # Find all video blocks (anchor tags with href starting with /video/)
    for match in re.finditer(r'<a[^>]+href="(/video/[^"]+)"[^>]*>(.*?)</a>', html, re.DOTALL):
        href, inner = match.groups()
        video_url = base_url + href
        # Parse the video page for real title and poster
        try:
            video_html = get_html(video_url)
        except Exception:
            continue
        real_title = parse_og_meta(video_html, 'og:title')
        poster = parse_og_meta(video_html, 'og:image')
        if not real_title:
            # fallback: try to get from img alt or text
            img_match = re.search(r'<img[^>]+alt="([^"]+)"[^>]*src="([^"]+)"', inner)
            if img_match:
                real_title = img_match.group(1).strip()
            else:
                text = re.sub('<[^<]+?>', '', inner).strip()
                if text:
                    real_title = text
        if not real_title:
            continue
        li = xbmcgui.ListItem(label=real_title)
        if poster:
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': fanart, 'poster': poster})
        else:
            li.setArt({'fanart': fanart})
        li.setInfo('video', {'title': real_title})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_streams', 'video_url': video_url, 'title': real_title, 'poster': poster}),
            listitem=li,
            isFolder=True
        )
    # Pagination: Previous Page
    if page > 1:
        prev_page_url = f"{base}?page={page-1}"
        li = xbmcgui.ListItem(label=f"[B]Previous Page ({page-1}/{max_pages})[/B]")
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_videos', 'cat_url': prev_page_url}),
            listitem=li,
            isFolder=True
        )
    # Pagination: Next Page
    if page < max_pages:
        next_page_url = f"{base}?page={page+1}"
        li = xbmcgui.ListItem(label=f"[B]Next Page ({page+1}/{max_pages})[/B]")
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_videos', 'cat_url': next_page_url}),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.setPluginFanart(addon_handle, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

def list_search(query, page=1):
    search_url = f"{base_url}/search/videos?search_query={urllib.parse.quote(query)}"
    if page > 1:
        search_url += f"&page={page}"
    html = get_html(search_url)
    xbmcplugin.setPluginCategory(addon_handle, f"Hledat: {query} (Page {page})")
    for match in re.finditer(r'<a[^>]+href="(/video/[^"]+)"[^>]*>(.*?)</a>', html, re.DOTALL):
        href, inner = match.groups()
        video_url = base_url + href
        try:
            video_html = get_html(video_url)
        except Exception:
            continue
        real_title = parse_og_meta(video_html, 'og:title')
        poster = parse_og_meta(video_html, 'og:image')
        if not real_title:
            img_match = re.search(r'<img[^>]+alt="([^"]+)"[^>]*src="([^"]+)"', inner)
            if img_match:
                real_title = img_match.group(1).strip()
            else:
                text = re.sub('<[^<]+?>', '', inner).strip()
                if text:
                    real_title = text
        if not real_title:
            continue
        li = xbmcgui.ListItem(label=real_title)
        if poster:
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': fanart, 'poster': poster})
        else:
            li.setArt({'fanart': fanart})
        li.setInfo('video', {'title': real_title})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'list_streams', 'video_url': video_url, 'title': real_title, 'poster': poster}),
            listitem=li,
            isFolder=True
        )
    # Pagination for search: look for next page
    next_match = re.search(r'<a[^>]+href=["\"]/search/videos\?search_query=[^"\"]+&page=(\d+)["\"][^>]*>\s*(Show More|Next|Další|Více)[^<]*<', html, re.IGNORECASE)
    if next_match:
        next_page = int(next_match.group(1))
        li = xbmcgui.ListItem(label=f"[B]Next Page ({next_page})[/B]")
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'search_results', 'query': query, 'page': next_page}),
            listitem=li,
            isFolder=True
        )
    if page > 1:
        prev_page = page - 1
        li = xbmcgui.ListItem(label=f"[B]Previous Page ({prev_page})[/B]")
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({'mode': 'search_results', 'query': query, 'page': prev_page}),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.setPluginFanart(addon_handle, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

def list_streams(video_url, title=None, poster=None):
    html = get_html(video_url)
    real_title = parse_og_meta(html, 'og:title') or title or ''
    real_poster = parse_og_meta(html, 'og:image') or poster or None
    video_block = re.search(r'<video[^>]*>(.*?)</video>', html, re.DOTALL)
    if not video_block:
        xbmcgui.Dialog().notification('SkTonline', 'No video sources found!', xbmcgui.NOTIFICATION_ERROR)
        return
    sources = re.findall(r'<source[^>]+src="([^"]+?)"[^>]+label=[\'\"]?([^\'\" >]+)', video_block.group(1))
    if not sources:
        sources = re.findall(r'<source[^>]+src="([^"]+?)"', video_block.group(1))
        sources = [(src, 'Stream') for src in sources]
    for stream_url, label in sources:
        if stream_url.startswith('http'):
            stream_label = f"{real_title} ({label})" if real_title else label
            li = xbmcgui.ListItem(label=stream_label)
            li.setInfo('video', {'title': stream_label})
            li.setProperty('IsPlayable', 'true')
            # Use 480p or 720p icon if label contains 480 or 720
            if '480' in label:
                li.setArt({'icon': icon_480, 'thumb': icon_480, 'fanart': fanart})
            elif '720' in label:
                li.setArt({'icon': icon_720, 'thumb': icon_720, 'fanart': fanart})
            else:
                li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
            xbmcplugin.addDirectoryItem(
                handle=addon_handle,
                url=stream_url,
                listitem=li,
                isFolder=False
            )
            # Add to history (only for the first stream per video)
            add_to_history(real_title, video_url, real_poster)
    xbmcplugin.setPluginFanart(addon_handle, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode is None:
        list_categories()
    elif mode == 'list_videos':
        list_videos(params['cat_url'])
    elif mode == 'list_streams':
        list_streams(params['video_url'], params.get('title'), params.get('poster'))
    elif mode == 'search':
        kb = xbmcgui.Dialog().input('Hledat', type=xbmcgui.INPUT_ALPHANUM)
        if kb:
            list_search(kb)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'search_results':
        query = params.get('query', '')
        page = int(params.get('page', '1'))
        list_search(query, page)
    elif mode == 'history':
        list_history()
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:]) 